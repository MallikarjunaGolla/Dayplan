import { AfterViewInit, Component, Compiler, Injector, ViewChild, ViewContainerRef } from '@angular/core';
import {DayPlanService} from '../../core';
declare const SystemJS: any;
@Component({
  selector: 'day-plan',
  templateUrl: './dayplan.component.html',
  styleUrls: ['./dayplan.component.css']
})
export class DayPlanComponent implements AfterViewInit {
  @ViewChild('breakfastcontent', {static: true, read: ViewContainerRef }) breakfastcontent: ViewContainerRef;
  @ViewChild('lunchfastcontent', {static: true, read: ViewContainerRef }) lunchcontent: ViewContainerRef;
  @ViewChild('cardfastcontent', {static: true, read: ViewContainerRef }) dinnercontent: ViewContainerRef;
  constructor(private _compiler: Compiler, private _injector: Injector,private dayPlanService:DayPlanService) { }
  ngAfterViewInit() {
    this.dayPlanService.LoadPlugin(this.breakfastcontent,this._compiler,this._injector,"breakfast","BreakfastModule");
    this.dayPlanService.LoadPlugin(this.lunchcontent,this._compiler,this._injector,"lunch","LunchModule");
    this.dayPlanService.LoadPlugin(this.dinnercontent,this._compiler,this._injector,"dinner","DinnerModule");
  }
}
