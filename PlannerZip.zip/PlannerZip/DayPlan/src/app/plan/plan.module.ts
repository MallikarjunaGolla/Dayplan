import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DayPlanComponent } from './components';
import { PlanRoutes } from './plan.routes';
import { DayPlanService } from './core';
@NgModule({
    declarations: [
        DayPlanComponent
    ],
    imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
        PlanRoutes
    ],
    providers: [
        DayPlanService
    ]
})

export class PlanModule { }
