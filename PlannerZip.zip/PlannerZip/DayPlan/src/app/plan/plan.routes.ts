import { RouterModule, Routes } from '@angular/router';
import { DayPlanComponent} from './components';

const routes: Routes = [
    { path: 'dpln', component: DayPlanComponent },
];
export const PlanRoutes = RouterModule.forChild(routes);
