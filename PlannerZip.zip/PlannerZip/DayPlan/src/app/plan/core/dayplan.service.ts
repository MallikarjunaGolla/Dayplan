﻿import { Injectable, Compiler, Injector, ViewContainerRef } from '@angular/core';
declare const SystemJS: any;
@Injectable()
export class DayPlanService {
    async LoadPlugin(content:ViewContainerRef,_compiler: Compiler,_injector: Injector, bundle:string,modulename:string) {
        const module = await SystemJS.import("assets/plugins/"+bundle+".bundle.js");
        const moduleFactory = await _compiler.compileModuleAsync<any>(module[modulename]);
        const moduleRef = moduleFactory.create(_injector);
        const componentProvider = moduleRef.injector.get('plugins');
        const componentFactory = moduleRef.componentFactoryResolver
                                       .resolveComponentFactory<any>(
                                           componentProvider[0][0].component
                                       );
        content.createComponent(componentFactory);
        }
}