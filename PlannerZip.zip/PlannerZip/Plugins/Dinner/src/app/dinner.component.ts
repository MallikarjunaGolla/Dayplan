import { Component } from '@angular/core';

@Component({
  selector: 'dinner',
  templateUrl: './dinner.component.html',
  styleUrls: ['./dinner.component.css']
})
export class DinnerComponent {

  constructor() { }
}