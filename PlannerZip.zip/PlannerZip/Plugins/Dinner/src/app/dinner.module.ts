import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DinnerComponent } from './dinner.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [DinnerComponent],
  entryComponents: [DinnerComponent],
  providers: [{
     provide: 'plugins',
     useValue: [{
       name: 'dinnercomponent',
       component: DinnerComponent
     }],
     multi: true
   }]
})
export class DinnerModule { }