import { Component } from '@angular/core';

@Component({
  selector: 'breakfast',
  templateUrl: './breakfast.component.html',
  styleUrls: ['./breakfast.component.css']
})
export class BreakfastComponent {

  constructor() { }
}