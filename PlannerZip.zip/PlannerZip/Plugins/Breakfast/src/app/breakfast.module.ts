import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BreakfastComponent } from './breakfast.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [BreakfastComponent],
  entryComponents: [BreakfastComponent],
  providers: [{
     provide: 'plugins',
     useValue: [{
       name: 'breakfastcomponent',
       component: BreakfastComponent
     }],
     multi: true
   }]
})
export class BreakfastModule { }