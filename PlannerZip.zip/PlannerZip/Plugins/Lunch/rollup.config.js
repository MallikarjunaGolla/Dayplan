import angular from 'rollup-plugin-angular';
import resolve from 'rollup-plugin-node-resolve';
import typescript from 'rollup-plugin-typescript2';
import commonjs from 'rollup-plugin-commonjs';

export default [{
   input: 'src/main.ts',
   output: {
     file: '../../DayPlan/src/assets/plugins/lunch.bundle.js',   
     format: 'umd',
     name: 'lunch',
},
   plugins: [
     angular(),
     resolve({
        jsnext: true,
        main: true,
        customResolveOptions: {
           moduleDirectory: 'node_modules'
        }
     }),
     typescript({
       typescript: require('typescript')
     }),
     commonjs()
   ],
   external: [
     '@angular/core',
     '@angular/common',
     '@angular/forms'
   ]
}]