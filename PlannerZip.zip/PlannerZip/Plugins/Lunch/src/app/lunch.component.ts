import { Component } from '@angular/core';

@Component({
  selector: 'lunch',
  templateUrl: './lunch.component.html',
  styleUrls: ['./lunch.component.css']
})
export class LunchComponent {

  constructor() { }
}