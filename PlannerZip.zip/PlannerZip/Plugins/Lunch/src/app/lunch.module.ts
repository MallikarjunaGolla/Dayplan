import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LunchComponent } from './lunch.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LunchComponent],
  entryComponents: [LunchComponent],
  providers: [{
     provide: 'plugins',
     useValue: [{
       name: 'dinnercomponent',
       component: LunchComponent
     }],
     multi: true
   }]
})
export class LunchModule { }